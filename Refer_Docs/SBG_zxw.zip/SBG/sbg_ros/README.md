# sbg_ros_driver
ROS driver for SBG System Ellipse IMU
